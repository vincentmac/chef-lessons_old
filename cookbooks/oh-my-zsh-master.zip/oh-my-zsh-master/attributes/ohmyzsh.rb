default[:ohmyzsh][:theme] = "afowler"
